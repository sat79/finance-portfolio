# Manual synthesis evidence pack

Company: MICROSOFT CORP (MSFT). Research cutoff: 2026-10-26T18:04:45.673930+00:00.

Extract this ZIP. In your own ChatGPT conversation, attach evidence.json and paste instructions.txt. Ask for a sample using only that evidence. This app does not send anything to ChatGPT or call a model during export.

Keep the result labelled as a manual ChatGPT/Codex sample, not an application-provider response. The app does not import or automatically validate chat responses. Review source quotes, exact numerical records, periods, scope, limitations and unsupported causation. The complete research bundle retains the full appendix.
